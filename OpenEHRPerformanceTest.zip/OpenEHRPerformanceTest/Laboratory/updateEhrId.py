#!/usr/bin/env python3
import os
import json
import copy
from bson import ObjectId
from pymongo import MongoClient
from datetime import datetime

# ── CONFIG ────────────────────────────────────────────────────────────────
MONGO_URI        = "mongodb+srv://carlosalonso:admin1234@basicinitialtests.0asff.mongodb.net/?retryWrites=true&w=majority"
DB_NAME          = "CatSalutCDR"
COLL_NAME        = "finalCompositions"

# 1) Explicit ehr_id per batch
EHR_IDS_BY_BATCH = {
    1:    "7321ad5a-94c5-44db-e5b3-b76e73f05d63~r148X",    # for 1,50,250
    50:   "7321ad5a-94c5-44db-e5b3-b76e73f05d63~r148X",
    250:  "7321ad5a-94c5-44db-e5b3-b76e73f05d63~r148X",
    1000: "7321ad5a-94c5-44db-e5b3-b76e73f05d63~r148XL",   # special for 1000+
    5000: "7321ad5a-94c5-44db-e5b3-b76e73f05d63~r148XL",
    10000:"7321ad5a-94c5-44db-e5b3-b76e73f05d63~r148XL",
}

# 2) Explicit suffix per batch
SUFFIX_BY_BATCH  = {
    1:    "X1",
    50:   "X50",
    250:  "X250",
    1000: "X1000",
    5000: "X5000",
    10000:"X10000",
}

BATCH_SIZES      = list(EHR_IDS_BY_BATCH.keys())

# which cn‐element to tweak (matches your second elemMatch)
TARGET_ANI       = 110000

# ── DATE PARSER ────────────────────────────────────────────────────────────
def _parse_dates(obj):
    if isinstance(obj, dict):
        if "$date" in obj:
            s = obj["$date"].rstrip("Z")
            return datetime.fromisoformat(s)
        return {k: _parse_dates(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_parse_dates(v) for v in obj]
    else:
        return obj

# ── PATCHER ────────────────────────────────────────────────────────────────
def patch_doc(doc: dict, target_eid: str, suffix: str) -> dict:
    # set our per‐batch ehr_id
    doc["ehr_id"]  = target_eid
    doc["updated"] = True

    # find the element where d.ani == TARGET_ANI
    for elem in doc.get("cn", []):
        if elem.get("d", {}).get("ani") == TARGET_ANI:
            # append the suffix onto its code
            old_cs = elem["d"]["v"]["df"]["cs"]
            elem["d"]["v"]["df"]["cs"] = old_cs + suffix
            break

    return doc

# ── MAIN ──────────────────────────────────────────────────────────────────
def main():
    # load & normalize dates in your JSON template
    here          = os.path.dirname(__file__)
    template_path = os.path.join(here, "templates", "template.json")
    print(f"🔧 Loading template from: {template_path}")
    with open(template_path, "r") as f:
        raw = json.load(f)
    template = _parse_dates(raw)
    template.pop("_id", None)
    template.pop("updated", None)

    # connect
    client = MongoClient(MONGO_URI)
    coll   = client[DB_NAME][COLL_NAME]

    # clone & insert per batch
    for batch in BATCH_SIZES:
        target_eid = EHR_IDS_BY_BATCH[batch]
        suffix     = SUFFIX_BY_BATCH[batch]
        clones     = []

        for _ in range(batch):
            doc = patch_doc(copy.deepcopy(template), target_eid, suffix)
            doc["_id"] = ObjectId()
            clones.append(doc)

        res = coll.insert_many(clones)
        print(f"✅ Inserted {len(res.inserted_ids):4d} docs  "
              f"(ehr_id={target_eid!r}, suffix={suffix}, batch={batch})")

    print("🎉 All batches inserted.")

if __name__ == "__main__":
    main()