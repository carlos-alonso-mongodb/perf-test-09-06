#!/usr/bin/env python3
"""
denormalize_time.py – read a list of _ids from ids.txt, for each:
  • find the element in sn[] with hx == HX_VALUE
  • extract d.time.v from that element
  • set top‐level field first_sn_time to that date

Run:
    python updateAddSortField.py --db CatSalutCDR --coll search \
        --ids-file ids.txt --hx -99357964256156272 \
        --batch-size 1000
"""

import os
import argparse
from pathlib import Path
from pymongo import MongoClient, UpdateOne
from pymongo.errors import BulkWriteError
from bson import ObjectId

# ---------- parse CLI args ----------
parser = argparse.ArgumentParser()
parser.add_argument("--db",       required=True, help="database name")
parser.add_argument("--coll",     required=True, help="collection name")
parser.add_argument("--ids-file", required=True,
                    help="newline-delimited file of ObjectId hex strings")
parser.add_argument("--hx",       type=int, default=441413179318273650,
                    help="sn.hx value to match (default: 441413179318273650)")
parser.add_argument("--batch-size", type=int, default=1000,
                    help="how many updates per bulkWrite (default: 1000)")
args = parser.parse_args()

# ---------- connect to MongoDB ----------
client = MongoClient(
    host=os.environ.get("MONGODB_URI"),
    retryWrites=True,
    tls=True,
    tlsAllowInvalidCertificates=True
)
coll = client[args.db][args.coll]

# ---------- read ids ----------
ids_path = Path(args.ids_file)
with ids_path.open("r") as fh:
    ids = [ObjectId(line.strip()) for line in fh if line.strip()]

print(f"Loaded {len(ids)} _id(s) from {ids_path}")

# ---------- process in batches ----------
def process_batch(batch_ids):
    """
    For each _id in batch_ids, fetch the document, extract the time
    from the sn element with hx==args.hx, and build an UpdateOne.
    """
    ops = []
    # fetch all docs in one go
    docs = coll.find(
        {"_id": {"$in": batch_ids}},
        {"sn.hx": 1, "sn.d.time.v": 1}
    )

    for doc in docs:
        first_time = None
        for elem in doc.get("sn", []):
            # hx is an array of NumberLongs; match any:
            hx_vals = [int(x) for x in elem.get("hx", [])]
            if args.hx in hx_vals:
                # pull the nested date
                dt = elem.get("d", {}) \
                         .get("time", {}) \
                         .get("v")
                if dt:
                    first_time = dt
                break

        if first_time:
            ops.append(
                UpdateOne(
                    {"_id": doc["_id"]},
                    {"$set": {"sort-time": first_time}}
                )
            )
        else:
            # no matching element or no time — skip or log as you like
            pass

    if not ops:
        return 0

    try:
        result = coll.bulk_write(ops, ordered=False)
        return result.modified_count
    except BulkWriteError as bwe:
        print("Bulk write error:", bwe.details)
        return 0

total_updated = 0
for i in range(0, len(ids), args.batch_size):
    batch = ids[i : i + args.batch_size]
    updated = process_batch(batch)
    total_updated += updated
    print(f"Batch {i//args.batch_size + 1}: Updated {updated} docs")

print(f"Done — total documents updated: {total_updated}")