#!/usr/bin/env python3
"""
update_cs.py – find documents whose sn.hx == HX_VALUE and
sn.d.v.df.cs == OLD_CODE, then replace the code string with REPLACEMENT.

Run example:
    python update_cs.py --db lab --coll records \
        --replacement E08099999

If you omit --old-code or --hx, defaults will be used.
"""

import os
import argparse
from pathlib import Path
from pymongo import MongoClient, UpdateOne
from pymongo.errors import BulkWriteError

# ---------- configuration via CLI ----------
parser = argparse.ArgumentParser()
parser.add_argument("--db", required=True, help="database name")
parser.add_argument("--coll", required=True, help="collection name")
parser.add_argument("--limit", type=int, default=1000,
                    help="max number of docs to modify")
parser.add_argument("--old-code", default="E08002720",
                    help='existing code string to replace (default: "E08002720")')
parser.add_argument("--replacement", required=True,
                    help='new code string to set, e.g. "E08099999"')
parser.add_argument("--hx", type=int, default=-99357964256156272,
                    help="numeric value of sn.hx to match (default: -99357964256156272)")
args = parser.parse_args()

# ---------- connect ----------
client = MongoClient(
    host=os.environ.get("MONGODB_URI"),
    appname="cs-updater",
    retryWrites=True,
    tls=True,
    tlsAllowInvalidCertificates=True  # skip SSL cert validation
)
coll = client[args.db][args.coll]

# ---------- 1. fetch _id list through $search ----------
pipeline = [
    {
        "$search": {
            "index": "default",
            "compound": {
                "filter": [
                    {
                        "embeddedDocument": {
                            "path": "sn",
                            "operator": {
                                "compound": {
                                    "filter": [
                                        { "equals": { "path": "sn.hx",         "value": args.hx }},
                                        { "equals": { "path": "sn.d.v.df.cs", "value": args.old_code }},
                                    ]
                                }
                            }
                        }
                    }
                ]
            }
        }
    },
    { "$limit": args.limit },
    { "$project": { "_id": 1 } },
]

ids = [doc["_id"] for doc in coll.aggregate(pipeline, allowDiskUse=True)]
print(f"Fetched {len(ids)} document IDs matching hx={args.hx} & cs={args.old_code!r}")

if not ids:
    print("Nothing to update – exiting.")
    exit(0)

# ---------- 2. build bulk updates ----------
bulk_ops = [
    UpdateOne(
        {"_id": _id},
        {"$set": {"sn.$[elem].d.v.df.cs": args.replacement}},
        array_filters=[{
            "elem.hx": args.hx,
            "elem.d.v.df.cs": args.old_code
        }],
    )
    for _id in ids
]

# ---------- 3. write the list of _ids to disk ----------
out_path = Path(f"{args.old_code}_to_{args.replacement}.txt")
with out_path.open("w", encoding="utf-8") as fh:
    for _id in ids:
        fh.write(f"{_id}\n")
print(f"Wrote {len(ids)} ObjectIds to {out_path.resolve()}")

# ---------- 4. execute bulk write ----------
try:
    result = coll.bulk_write(bulk_ops, ordered=False)
    print(
        f"Matched {result.matched_count} – "
        f"Modified {result.modified_count} – "
        f"Upserts {result.upserted_count}"
    )
except BulkWriteError as bwe:
    print("Bulk write error details:")
    for err in bwe.details.get("writeErrors", []):
        print(err)