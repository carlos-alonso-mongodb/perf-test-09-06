#!/usr/bin/env python3
import time
import csv
import importlib
import math
import helper
import socket
import re
import os
from datetime import datetime

# ——— CONFIG ———
RUNS          = 20           # iterations per query module
WAIT_BETWEEN  = 1            # seconds to pause between iterations
MODULES = [
    # Laboratory match ehr_uid sort
    "poc5.laboratory.match.queries.sort.query_X1",
    "poc5.laboratory.match.queries.sort.query_X10",
    "poc5.laboratory.match.queries.sort.query_X50",
    "poc5.laboratory.match.queries.sort.query_X250",
    "poc5.laboratory.match.queries.sort.query_X1000",
    "poc5.laboratory.match.queries.sort.query_X5000",
    "poc5.laboratory.match.queries.sort.query_X10000",
    # Laboratory match ehr_uid nosort
    "poc5.laboratory.match.queries.nosort.query_X1",
    "poc5.laboratory.match.queries.nosort.query_X10",
    "poc5.laboratory.match.queries.nosort.query_X50",
    "poc5.laboratory.match.queries.nosort.query_X250",
    "poc5.laboratory.match.queries.nosort.query_X1000",
    "poc5.laboratory.match.queries.nosort.query_X5000",
    "poc5.laboratory.match.queries.nosort.query_X10000",
    # Vaccinations equal
    "poc5.vaccinations.search.queries.equal-nosort.query_X1",
    "poc5.vaccinations.search.queries.equal-nosort.query_X10",
    "poc5.vaccinations.search.queries.equal-nosort.query_X50",
    "poc5.vaccinations.search.queries.equal-nosort.query_X250",
    "poc5.vaccinations.search.queries.equal-nosort.query_X1000",
    "poc5.vaccinations.search.queries.equal-nosort.query_X5000",
    "poc5.vaccinations.search.queries.equal-nosort.query_X10000",
    "poc5.vaccinations.search.queries.equal-nosort.query_X100000",
    # Laboratory equal
    "poc5.laboratory.search.queries.equal-nosort.query_X1",
    "poc5.laboratory.search.queries.equal-nosort.query_X10",
    "poc5.laboratory.search.queries.equal-nosort.query_X50",
    "poc5.laboratory.search.queries.equal-nosort.query_X250",
    "poc5.laboratory.search.queries.equal-nosort.query_X1000",
    "poc5.laboratory.search.queries.equal-nosort.query_X5000",
    "poc5.laboratory.search.queries.equal-nosort.query_X10000",
    "poc5.laboratory.search.queries.equal-nosort.query_X100000",
    # Vaccinations wildcard
    "poc5.vaccinations.search.queries.wildcard-nosort.query_X1",
    "poc5.vaccinations.search.queries.wildcard-nosort.query_X10",
    "poc5.vaccinations.search.queries.wildcard-nosort.query_X50",
    "poc5.vaccinations.search.queries.wildcard-nosort.query_X250",
    "poc5.vaccinations.search.queries.wildcard-nosort.query_X1000",
    "poc5.vaccinations.search.queries.wildcard-nosort.query_X5000",
    "poc5.vaccinations.search.queries.wildcard-nosort.query_X10000",
    "poc5.vaccinations.search.queries.wildcard-nosort.query_X100000",
    # Laboratory wildcard
    "poc5.laboratory.search.queries.wildcard-nosort.query_X1",
    "poc5.laboratory.search.queries.wildcard-nosort.query_X10",
    "poc5.laboratory.search.queries.wildcard-nosort.query_X50",
    "poc5.laboratory.search.queries.wildcard-nosort.query_X250",
    "poc5.laboratory.search.queries.wildcard-nosort.query_X1000",
    "poc5.laboratory.search.queries.wildcard-nosort.query_X5000",
    "poc5.laboratory.search.queries.wildcard-nosort.query_X10000",
    "poc5.laboratory.search.queries.wildcard-nosort.query_X100000",
    # Vaccinations equal-sort
    "poc5.vaccinations.search.queries.equal-sort.query_X1",
    "poc5.vaccinations.search.queries.equal-sort.query_X10",
    "poc5.vaccinations.search.queries.equal-sort.query_X50",
    "poc5.vaccinations.search.queries.equal-sort.query_X250",
    "poc5.vaccinations.search.queries.equal-sort.query_X1000",
    "poc5.vaccinations.search.queries.equal-sort.query_X5000",
    "poc5.vaccinations.search.queries.equal-sort.query_X10000",
    "poc5.vaccinations.search.queries.equal-sort.query_X100000",
    # Laboratory equal-sort
    "poc5.laboratory.search.queries.equal-sort.query_X1",
    "poc5.laboratory.search.queries.equal-sort.query_X10",
    "poc5.laboratory.search.queries.equal-sort.query_X50",
    "poc5.laboratory.search.queries.equal-sort.query_X250",
    "poc5.laboratory.search.queries.equal-sort.query_X1000",
    "poc5.laboratory.search.queries.equal-sort.query_X5000",
    "poc5.laboratory.search.queries.equal-sort.query_X10000",
    "poc5.laboratory.search.queries.equal-sort.query_X100000",
    # Vaccinations wildcard-sort
    "poc5.vaccinations.search.queries.wildcard-sort.query_X1",
    "poc5.vaccinations.search.queries.wildcard-sort.query_X10",
    "poc5.vaccinations.search.queries.wildcard-sort.query_X50",
    "poc5.vaccinations.search.queries.wildcard-sort.query_X250",
    "poc5.vaccinations.search.queries.wildcard-sort.query_X1000",
    "poc5.vaccinations.search.queries.wildcard-sort.query_X5000",
    "poc5.vaccinations.search.queries.wildcard-sort.query_X10000",
    "poc5.vaccinations.search.queries.wildcard-sort.query_X100000",
    # Laboratory wildcard-sort
    "poc5.laboratory.search.queries.wildcard-sort.query_X1",
    "poc5.laboratory.search.queries.wildcard-sort.query_X10",
    "poc5.laboratory.search.queries.wildcard-sort.query_X50",
    "poc5.laboratory.search.queries.wildcard-sort.query_X250",
    "poc5.laboratory.search.queries.wildcard-sort.query_X1000",
    "poc5.laboratory.search.queries.wildcard-sort.query_X5000",
    "poc5.laboratory.search.queries.wildcard-sort.query_X10000",
    "poc5.laboratory.search.queries.wildcard-sort.query_X100000",
    # Vaccinations equal-sort-limit1000
    "poc5.vaccinations.search.queries.equal-sort-limit1000.query_X1",
    "poc5.vaccinations.search.queries.equal-sort-limit1000.query_X10",
    "poc5.vaccinations.search.queries.equal-sort-limit1000.query_X50",
    "poc5.vaccinations.search.queries.equal-sort-limit1000.query_X250",
    "poc5.vaccinations.search.queries.equal-sort-limit1000.query_X1000",
    "poc5.vaccinations.search.queries.equal-sort-limit1000.query_X5000",
    "poc5.vaccinations.search.queries.equal-sort-limit1000.query_X10000",
    "poc5.vaccinations.search.queries.equal-sort-limit1000.query_X100000",
    # Laboratory equal-sort-limit1000
    "poc5.laboratory.search.queries.equal-sort-limit1000.query_X1",
    "poc5.laboratory.search.queries.equal-sort-limit1000.query_X10",
    "poc5.laboratory.search.queries.equal-sort-limit1000.query_X50",
    "poc5.laboratory.search.queries.equal-sort-limit1000.query_X250",
    "poc5.laboratory.search.queries.equal-sort-limit1000.query_X1000",
    "poc5.laboratory.search.queries.equal-sort-limit1000.query_X5000",
    "poc5.laboratory.search.queries.equal-sort-limit1000.query_X10000",
    "poc5.laboratory.search.queries.equal-sort-limit1000.query_X100000",
# Vaccinations equal-sort-nolookupproject
    "poc5.vaccinations.search.queries.equal-sort-nolookup.query_X1",
    "poc5.vaccinations.search.queries.equal-sort-nolookup.query_X10",
    "poc5.vaccinations.search.queries.equal-sort-nolookup.query_X50",
    "poc5.vaccinations.search.queries.equal-sort-nolookup.query_X250",
    "poc5.vaccinations.search.queries.equal-sort-nolookup.query_X1000",
    "poc5.vaccinations.search.queries.equal-sort-nolookup.query_X5000",
    "poc5.vaccinations.search.queries.equal-sort-nolookup.query_X10000",
    "poc5.vaccinations.search.queries.equal-sort-nolookup.query_X100000",
    # Laboratory equal-sort-nolookupproject
    "poc5.laboratory.search.queries.equal-sort-nolookup.query_X1",
    "poc5.laboratory.search.queries.equal-sort-nolookup.query_X10",
    "poc5.laboratory.search.queries.equal-sort-nolookup.query_X50",
    "poc5.laboratory.search.queries.equal-sort-nolookup.query_X250",
    "poc5.laboratory.search.queries.equal-sort-nolookup.query_X1000",
    "poc5.laboratory.search.queries.equal-sort-nolookup.query_X5000",
    "poc5.laboratory.search.queries.equal-sort-nolookup.query_X10000",
    "poc5.laboratory.search.queries.equal-sort-nolookup.query_X100000",
    # Vaccinations equal-sort-noss 
    "poc5.vaccinations.search.queries.equal-sort-noss.query_X1",
    "poc5.vaccinations.search.queries.equal-sort-noss.query_X10",
    "poc5.vaccinations.search.queries.equal-sort-noss.query_X50",
    "poc5.vaccinations.search.queries.equal-sort-noss.query_X250",
    "poc5.vaccinations.search.queries.equal-sort-noss.query_X1000",
    "poc5.vaccinations.search.queries.equal-sort-noss.query_X5000",
    "poc5.vaccinations.search.queries.equal-sort-noss.query_X10000",
    "poc5.vaccinations.search.queries.equal-sort-noss.query_X100000",
    # Laboratory equal-sort
    "poc5.laboratory.search.queries.equal-sort-noss.query_X1",
    "poc5.laboratory.search.queries.equal-sort-noss.query_X10",
    "poc5.laboratory.search.queries.equal-sort-noss.query_X50",
    "poc5.laboratory.search.queries.equal-sort-noss.query_X250",
    "poc5.laboratory.search.queries.equal-sort-noss.query_X1000",
    "poc5.laboratory.search.queries.equal-sort-noss.query_X5000",
    "poc5.laboratory.search.queries.equal-sort-noss.query_X10000",
    "poc5.laboratory.search.queries.equal-sort-noss.query_X100000",
    # Vaccinations wildcard-sort
    "poc5.vaccinations.search.queries.wildcard-sort-noss.query_X1",
    "poc5.vaccinations.search.queries.wildcard-sort-noss.query_X10",
    "poc5.vaccinations.search.queries.wildcard-sort-noss.query_X50",
    "poc5.vaccinations.search.queries.wildcard-sort-noss.query_X250",
    "poc5.vaccinations.search.queries.wildcard-sort-noss.query_X1000",
    "poc5.vaccinations.search.queries.wildcard-sort-noss.query_X5000",
    "poc5.vaccinations.search.queries.wildcard-sort-noss.query_X10000",
    "poc5.vaccinations.search.queries.wildcard-sort-noss.query_X100000",
    # Laboratory wildcard-sort
    "poc5.laboratory.search.queries.wildcard-sort-noss.query_X1",
    "poc5.laboratory.search.queries.wildcard-sort-noss.query_X10",
    "poc5.laboratory.search.queries.wildcard-sort-noss.query_X50",
    "poc5.laboratory.search.queries.wildcard-sort-noss.query_X250",
    "poc5.laboratory.search.queries.wildcard-sort-noss.query_X1000",
    "poc5.laboratory.search.queries.wildcard-sort-noss.query_X5000",
    "poc5.laboratory.search.queries.wildcard-sort-noss.query_X10000",
    "poc5.laboratory.search.queries.wildcard-sort-noss.query_X100000",
]

def get_test_name():
    return input("Enter test run name: ")

def get_output_path(test_name: str) -> str:
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    out_dir = "testRuns"
    os.makedirs(out_dir, exist_ok=True)
    filename = f"{timestamp}_{test_name}.csv"
    return os.path.join(out_dir, filename)

# Get machine IP
try:
    MACHINE_IP = socket.gethostbyname(socket.gethostname())
except Exception:
    MACHINE_IP = "unknown"

# CSV fields
def build_fields():
    return [
        "test_run", "module", "target_docs", "runs", "first_ts", "ip", "returned_docs",
        "ping_ms", "min_ms", "avg_ms", "p90_ms", "max_ms"
    ]

# Utility functions
def trimmed_times(times):
    n = len(times)
    if n < 3:
        return sorted(times)
    s = sorted(times)
    trim = max(int(n * 0.2), 1)
    return s[trim:-trim] if trim * 2 < n else s

def percentile(sorted_times, pct):
    if not sorted_times:
        return None
    rank = pct/100*(len(sorted_times)-1)
    lo, hi = math.floor(rank), math.ceil(rank)
    if lo == hi:
        return sorted_times[int(rank)]
    frac = rank - lo
    return sorted_times[lo]*(1-frac) + sorted_times[hi]*frac

# Measure initial metadata and first run
def init_module(mod_path):
    conn = helper.get_connection()
    ping_start = time.time()
    conn.admin.command('ping')
    ping_ms = (time.time() - ping_start)*1000
    mod = importlib.import_module(mod_path)
    # warm-up
    _ = mod.run_query() if hasattr(mod, "run_query") else mod.run_aggregation()
    # first run
    first_ts = datetime.now().isoformat()
    t0 = time.time()
    result = mod.run_query() if hasattr(mod, "run_query") else mod.run_aggregation()
    first_ms = (time.time()-t0)*1000
    docs = len(result)
    return {
        'mod': mod,
        'base': re.sub(r"\.query_X\d+$","",mod_path),
        'target': int(re.search(r"\.query_X(\d+)$",mod_path).group(1)) if re.search(r"\.query_X(\d+)$",mod_path) else None,
        'ping_ms': ping_ms,
        'times': [first_ms],
        'first_ts': first_ts,
        'docs': docs
    }

# CORE measurement loop
if __name__ == '__main__':
    test_name = get_test_name()
    csv_file = get_output_path(test_name)

    print("🔍 Starting performance test…", flush=True)
    # initialize modules
    meta = [init_module(m) for m in MODULES]
    # interleaved runs for the remaining iterations
    for i in range(1, RUNS):
        for m in meta:
            if WAIT_BETWEEN:
                time.sleep(WAIT_BETWEEN)
            t0 = time.time()
            _ = m['mod'].run_query() if hasattr(m['mod'], "run_query") else m['mod'].run_aggregation()
            m['times'].append((time.time()-t0)*1000)

    # Write CSV
    with open(csv_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=build_fields())
        writer.writeheader()
        for m in meta:
            mid = trimmed_times(m['times'])
            writer.writerow({
                'test_run': test_name,
                'module': m['base'],
                'target_docs': m['target'],
                'runs': RUNS,
                'first_ts': m['first_ts'],
                'ip': MACHINE_IP,
                'returned_docs': m['docs'],
                'ping_ms': round(m['ping_ms'],2),
                'min_ms': round(min(mid),2),
                'avg_ms': round(sum(mid)/len(mid),2),
                'p90_ms': round(percentile(sorted(mid),90),2),
                'max_ms': round(max(mid),2)
            })
    print(f"✅ Done – see {csv_file}")
